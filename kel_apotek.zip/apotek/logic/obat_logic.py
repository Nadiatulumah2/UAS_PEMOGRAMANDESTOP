from database.database import connect

def tambah_obat(nama, jenis, harga, stok, tanggal_kadaluwarsa):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO Obat (Nama_Obat, Jenis_Obat, Harga, Stok, Tanggal_Kadaluwarsa)
    VALUES (?, ?, ?, ?, ?)
    ''', (nama, jenis, harga, stok, tanggal_kadaluwarsa))
    conn.commit()
    conn.close()

def lihat_obat():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Obat')
    results = cursor.fetchall()
    conn.close()
    return results

def update_obat(id_obat, nama, jenis, harga, stok, tanggal_kadaluwarsa):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE Obat
    SET Nama_Obat = ?, Jenis_Obat = ?, Harga = ?, Stok = ?, Tanggal_Kadaluwarsa = ?
    WHERE ID_Obat = ?
    ''', (nama, jenis, harga, stok, tanggal_kadaluwarsa, id_obat))
    conn.commit()
    conn.close()

def delete_obat(id_obat):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM Obat WHERE ID_Obat = ?', (id_obat,))
    conn.commit()
    conn.close()
