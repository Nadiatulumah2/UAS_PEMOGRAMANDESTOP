from database.database import connect

def tambah_pelanggan(nama, alamat, nomor_telepon):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO Pelanggan (Nama_Pelanggan, Alamat, Nomor_Telepon)
    VALUES (?, ?, ?)
    ''', (nama, alamat, nomor_telepon))
    conn.commit()
    conn.close()

def lihat_pelanggan():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Pelanggan')
    results = cursor.fetchall()
    conn.close()
    return results

def update_pelanggan(id_pelanggan, nama, alamat, nomor_telepon):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    UPDATE Pelanggan
    SET Nama_Pelanggan = ?, Alamat = ?, Nomor_Telepon = ?
    WHERE ID_Pelanggan = ?
    ''', (nama, alamat, nomor_telepon, id_pelanggan))
    conn.commit()
    conn.close()

def delete_pelanggan(id_pelanggan):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM Pelanggan WHERE ID_Pelanggan = ?', (id_pelanggan,))
    conn.commit()
    conn.close()
