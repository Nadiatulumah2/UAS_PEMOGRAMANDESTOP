from database.database import connect

def laporan_penjualan_harian():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    SELECT Tanggal_Transaksi, SUM(Total_Harga) AS Total_Penjualan
    FROM Transaksi
    WHERE DATE(Tanggal_Transaksi) = DATE('now')
    GROUP BY Tanggal_Transaksi
    ''')
    results = cursor.fetchall()
    conn.close()
    return results
