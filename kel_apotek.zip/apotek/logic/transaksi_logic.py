from database.database import connect

def tambah_transaksi(id_pelanggan, id_obat, jumlah, total_harga):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO Transaksi (ID_Pelanggan, ID_Obat, Jumlah, Total_Harga)
    VALUES (?, ?, ?, ?)
    ''', (id_pelanggan, id_obat, jumlah, total_harga))
    conn.commit()
    conn.close()

def lihat_transaksi():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Transaksi')
    results = cursor.fetchall()
    conn.close()
    return results
