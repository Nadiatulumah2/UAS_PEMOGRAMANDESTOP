import tkinter as tk
from tkinter import ttk
from logic.laporan_logic import laporan_penjualan_harian

def open_laporan_window():
    window = tk.Toplevel()
    window.title("Laporan Penjualan Harian")
    window.geometry("600x400")

    columns = ("Tanggal", "Total Penjualan")
    table = ttk.Treeview(window, columns=columns, show="headings")
    for col in columns:
        table.heading(col, text=col)
        table.column(col, anchor="center", width=100)
    table.grid(row=0, column=0, padx=10, pady=10)

    # Menampilkan laporan penjualan harian
    for row in laporan_penjualan_harian():
        table.insert("", "end", values=row)

    window.mainloop()
