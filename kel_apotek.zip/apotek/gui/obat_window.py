import tkinter as tk
from tkinter import ttk, messagebox
from logic.obat_logic import tambah_obat, lihat_obat, update_obat, delete_obat

def open_obat_window():
    def refresh_table():
        for row in table.get_children():
            table.delete(row)
        for row in lihat_obat():
            table.insert("", "end", values=row)

    def add_data():
        try:
            tambah_obat(entry_nama.get(), entry_jenis.get(), float(entry_harga.get()),
                        int(entry_stok.get()), entry_kadaluwarsa.get())
            refresh_table()
            messagebox.showinfo("Sukses", "Data obat berhasil ditambahkan!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    def edit_data():
        try:
            selected_item = table.selection()[0]
            data = table.item(selected_item, "values")
            id_obat = data[0]
            update_obat(id_obat, entry_nama.get(), entry_jenis.get(), float(entry_harga.get()),
                        int(entry_stok.get()), entry_kadaluwarsa.get())
            refresh_table()
            messagebox.showinfo("Sukses", "Data obat berhasil diperbarui!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    def delete_data():
        try:
            selected_item = table.selection()[0]
            data = table.item(selected_item, "values")
            id_obat = data[0]
            delete_obat(id_obat)
            refresh_table()
            messagebox.showinfo("Sukses", "Data obat berhasil dihapus!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    window = tk.Toplevel()
    window.title("Manajemen Obat")
    window.geometry("800x600")

    tk.Label(window, text="Nama Obat").grid(row=0, column=0, padx=10, pady=5)
    entry_nama = tk.Entry(window)
    entry_nama.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(window, text="Jenis Obat").grid(row=1, column=0, padx=10, pady=5)
    entry_jenis = tk.Entry(window)
    entry_jenis.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(window, text="Harga").grid(row=2, column=0, padx=10, pady=5)
    entry_harga = tk.Entry(window)
    entry_harga.grid(row=2, column=1, padx=10, pady=5)

    tk.Label(window, text="Stok").grid(row=3, column=0, padx=10, pady=5)
    entry_stok = tk.Entry(window)
    entry_stok.grid(row=3, column=1, padx=10, pady=5)

    tk.Label(window, text="Tanggal Kadaluwarsa").grid(row=4, column=0, padx=10, pady=5)
    entry_kadaluwarsa = tk.Entry(window)
    entry_kadaluwarsa.grid(row=4, column=1, padx=10, pady=5)

    tk.Button(window, text="Tambah", command=add_data).grid(row=5, column=0, padx=10, pady=10)
    tk.Button(window, text="Edit", command=edit_data).grid(row=5, column=1, padx=10, pady=10)
    tk.Button(window, text="Hapus", command=delete_data).grid(row=5, column=2, padx=10, pady=10)

    columns = ("ID Obat", "Nama Obat", "Jenis Obat", "Harga", "Stok", "Tanggal Kadaluwarsa")
    table = ttk.Treeview(window, columns=columns, show="headings")
    for col in columns:
        table.heading(col, text=col)
        table.column(col, anchor="center", width=100)
    table.grid(row=6, column=0, columnspan=3, padx=10, pady=10)

    refresh_table()
