import tkinter as tk
from tkinter import ttk, messagebox
from logic.transaksi_logic import tambah_transaksi, lihat_transaksi
from logic.obat_logic import lihat_obat
from logic.pelanggan_logic import lihat_pelanggan

def open_transaksi_window():
    def refresh_table():
        for row in table.get_children():
            table.delete(row)
        for row in lihat_transaksi():
            table.insert("", "end", values=row)

    def add_data():
        try:
            id_pelanggan = int(entry_pelanggan.get())
            id_obat = int(entry_obat.get())
            jumlah = int(entry_jumlah.get())
            total_harga = jumlah * float(entry_harga.get())
            tambah_transaksi(id_pelanggan, id_obat, jumlah, total_harga)
            refresh_table()
            messagebox.showinfo("Sukses", "Transaksi berhasil ditambahkan!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    window = tk.Toplevel()
    window.title("Transaksi Penjualan")
    window.geometry("800x600")

    tk.Label(window, text="ID Pelanggan").grid(row=0, column=0, padx=10, pady=5)
    entry_pelanggan = tk.Entry(window)
    entry_pelanggan.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(window, text="ID Obat").grid(row=1, column=0, padx=10, pady=5)
    entry_obat = tk.Entry(window)
    entry_obat.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(window, text="Jumlah").grid(row=2, column=0, padx=10, pady=5)
    entry_jumlah = tk.Entry(window)
    entry_jumlah.grid(row=2, column=1, padx=10, pady=5)

    tk.Label(window, text="Harga Obat").grid(row=3, column=0, padx=10, pady=5)
    entry_harga = tk.Entry(window)
    entry_harga.grid(row=3, column=1, padx=10, pady=5)

    tk.Button(window, text="Tambah Transaksi", command=add_data).grid(row=4, column=0, padx=10, pady=10)

    columns = ("ID Transaksi", "ID Pelanggan", "ID Obat", "Jumlah", "Total Harga", "Tanggal Transaksi")
    table = ttk.Treeview(window, columns=columns, show="headings")
    for col in columns:
        table.heading(col, text=col)
        table.column(col, anchor="center", width=100)
    table.grid(row=5, column=0, columnspan=3, padx=10, pady=10)

    refresh_table()
