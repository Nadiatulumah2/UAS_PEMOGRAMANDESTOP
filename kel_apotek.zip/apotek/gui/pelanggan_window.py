import tkinter as tk
from tkinter import ttk, messagebox
from logic.pelanggan_logic import tambah_pelanggan, lihat_pelanggan, update_pelanggan, delete_pelanggan

def open_pelanggan_window():
    def refresh_table():
        for row in table.get_children():
            table.delete(row)
        for row in lihat_pelanggan():
            table.insert("", "end", values=row)

    def add_data():
        try:
            tambah_pelanggan(entry_nama.get(), entry_alamat.get(), entry_telepon.get())
            refresh_table()
            messagebox.showinfo("Sukses", "Data pelanggan berhasil ditambahkan!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    def edit_data():
        try:
            selected_item = table.selection()[0]
            data = table.item(selected_item, "values")
            id_pelanggan = data[0]
            update_pelanggan(id_pelanggan, entry_nama.get(), entry_alamat.get(), entry_telepon.get())
            refresh_table()
            messagebox.showinfo("Sukses", "Data pelanggan berhasil diperbarui!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    def delete_data():
        try:
            selected_item = table.selection()[0]
            data = table.item(selected_item, "values")
            id_pelanggan = data[0]
            delete_pelanggan(id_pelanggan)
            refresh_table()
            messagebox.showinfo("Sukses", "Data pelanggan berhasil dihapus!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {e}")

    window = tk.Toplevel()
    window.title("Manajemen Pelanggan")
    window.geometry("800x600")

    tk.Label(window, text="Nama Pelanggan").grid(row=0, column=0, padx=10, pady=5)
    entry_nama = tk.Entry(window)
    entry_nama.grid(row=0, column=1, padx=10, pady=5)

    tk.Label(window, text="Alamat").grid(row=1, column=0, padx=10, pady=5)
    entry_alamat = tk.Entry(window)
    entry_alamat.grid(row=1, column=1, padx=10, pady=5)

    tk.Label(window, text="Nomor Telepon").grid(row=2, column=0, padx=10, pady=5)
    entry_telepon = tk.Entry(window)
    entry_telepon.grid(row=2, column=1, padx=10, pady=5)

    tk.Button(window, text="Tambah", command=add_data).grid(row=3, column=0, padx=10, pady=10)
    tk.Button(window, text="Edit", command=edit_data).grid(row=3, column=1, padx=10, pady=10)
    tk.Button(window, text="Hapus", command=delete_data).grid(row=3, column=2, padx=10, pady=10)

    columns = ("ID Pelanggan", "Nama Pelanggan", "Alamat", "Nomor Telepon")
    table = ttk.Treeview(window, columns=columns, show="headings")
    for col in columns:
        table.heading(col, text=col)
        table.column(col, anchor="center", width=100)
    table.grid(row=4, column=0, columnspan=3, padx=10, pady=10)

    refresh_table()
