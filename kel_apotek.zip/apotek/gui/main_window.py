import tkinter as tk
from gui.obat_window import open_obat_window
from gui.pelanggan_window import open_pelanggan_window
from gui.transaksi_window import open_transaksi_window
from gui.laporan_window import open_laporan_window

def main_window():
    root = tk.Tk()
    root.title("Aplikasi Apotek")
    root.geometry("400x300")

    label = tk.Label(root, text="Selamat Datang di Aplikasi Apotek!", font=("Arial", 16))
    label.pack(pady=20)

    # Tombol untuk menuju halaman obat
    btn_obat = tk.Button(root, text="Manajemen Obat", command=open_obat_window)
    btn_obat.pack(pady=10)

    # Tombol untuk menuju halaman pelanggan
    btn_pelanggan = tk.Button(root, text="Manajemen Pelanggan", command=open_pelanggan_window)
    btn_pelanggan.pack(pady=10)

    # Tombol untuk menuju halaman transaksi
    btn_transaksi = tk.Button(root, text="Transaksi Penjualan", command=open_transaksi_window)
    btn_transaksi.pack(pady=10)

    # Tombol untuk menuju halaman laporan
    btn_laporan = tk.Button(root, text="Laporan Penjualan", command=open_laporan_window)
    btn_laporan.pack(pady=10)

    root.mainloop()
