import sqlite3

def connect():
    conn = sqlite3.connect('apotek.db')
    return conn

def create_tables():
    conn = connect()
    cursor = conn.cursor()

    # Tabel Obat
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Obat (
        ID_Obat INTEGER PRIMARY KEY AUTOINCREMENT,
        Nama_Obat TEXT NOT NULL,
        Jenis_Obat TEXT,
        Harga REAL,
        Stok INTEGER,
        Tanggal_Kadaluwarsa DATE
    )
    ''')

    # Tabel Pelanggan
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Pelanggan (
        ID_Pelanggan INTEGER PRIMARY KEY AUTOINCREMENT,
        Nama_Pelanggan TEXT NOT NULL,
        Alamat TEXT,
        Nomor_Telepon TEXT
    )
    ''')

    # Tabel Transaksi
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS Transaksi (
        ID_Transaksi INTEGER PRIMARY KEY AUTOINCREMENT,
        ID_Pelanggan INTEGER,
        ID_Obat INTEGER,
        Jumlah INTEGER,
        Total_Harga REAL,
        Tanggal_Transaksi DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ID_Pelanggan) REFERENCES Pelanggan(ID_Pelanggan),
        FOREIGN KEY (ID_Obat) REFERENCES Obat(ID_Obat)
    )
    ''')

    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_tables()
    print("Database berhasil diinisialisasi!")
