from gui.main_window import main_window

if __name__ == "__main__":
    main_window()
